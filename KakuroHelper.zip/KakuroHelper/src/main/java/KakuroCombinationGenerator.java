import java.util.HashSet;
import java.util.Set;

/**
 * Observable generator of Kakuro combinations.
 *
<!--//# BEGIN TODO: Name, student ID, and date-->
<p><b>Radu-Cristian Sarău, 1939149, 28 May 2024</b></p>
<!--//# END TODO-->
 */
public class KakuroCombinationGenerator implements Generator<Set<Integer>> {

    /**
     * Largest number in a Kakuro combination, with {@code 0 <= maxNumber}.
     */
    private int maxNumber;

    /**
     * The registered observer.
     */
    private GeneratorObserver<Set<Integer>> observer;

    /**
     * The most recently generated object.
     */
    private Set<Integer> object;

    /**
     * Constructs a generator without observer.
     */
    public KakuroCombinationGenerator() {
        this.observer = null;
        this.object = null;
        this.maxNumber = 9; // default
    }

    @Override
    public void setObserver(GeneratorObserver<Set<Integer>> observer) {
        this.observer = observer;
    }

    @Override
    public Set<Integer> getObject() {
        return new HashSet<>(object); // copy to avoid interference
    }

    /**
     * Sets largest number.
     *
     * @param maxNumber largest number that may occur
     * @pre {@code 0 <= maxNumber}
     */
    public void setMaxNumber(final int maxNumber) {
        if (maxNumber < 0) {
            throw new IllegalArgumentException(
                    "setMaxNumber precondition violated: maxNumber = " + maxNumber);
        }
        this.maxNumber = maxNumber;
    }

    /**
     * Gets largest number.
     *
     * @return largest number that may occur
     */
    public int getMaxNumber() {
        return this.maxNumber;
    }

    /**
     * Counts number of {@code generate(Set<Integer>, int, int, int)} calls.
     */
    public long count = 0;

    /**
     * Generates all combinations (modulo order of digits) of n distinct non-zero digits with sum s,
     * in lexicographic order (NOT ROBUST).
     *
     * @param n number of digits for extension
     * @param s digit sum for extension
     * @pre {@code 0 <= n}
     * @post each (sorted) combination of {@code n} distinct non-zero digits with sum {@code s} has
     *       been reported to the registered observer exactly once, in lexicographic order
     */
    public void generate(int s, int n) {
        count = 0;
        object = new HashSet<>();
        generate(object, s, n, 1);
    }

    /**
     * Generates all ways (modulo order of digits) in which a given combination can be extended by n
     * distinct non-zero digits at least k and with sum s, in lexicographic order (NOT ROBUST).
     *
     * @param c given combination to be extended
     * @param n number of digits for extension
     * @param s digit sum for extension
     * @param k lower bound for digits in extension
     * @pre {@code 0 <= n && 1 <= k && (\forall i; i : c; i < k)}
     * @modifies None
     * @post each (sorted) way of extending {@code c} with {@code n} distinct non-zero digits at
     *       least {@code k} and at most {@code maxNumber}, with sum {@code s}, has been reported to
     *       the registered observer exactly once, in lexicographic order
     * @bound {@code n} (upper bound on number of recursive calls)
     */
    private void generate(Set<Integer> c, int s, int n, int k) {
        count++;
        //# BEGIN TODO: Recursive implementation of generate(Set<Integer>, int, int, int)
        // Replace this line
        if (this.observer == null) {
            return;
        }
        
        if (areZeroes(n, s)) {
            observer.objectGenerated(this);
            return;
        }
        
        if (equalsOne(n)) {
            addDigit(k, s, c);
            return;
        }
        
        if (!conditionCreator(s, n, k)) {
            recursion(c, s, k, n);
        }
        
        
        
        //# END TODO
    }
    
    /**
     * Recursion process for finding combinations.
     * @param c given combination to be extended
     * @param n number of digits for extension
     * @param s digit sum for extension
     * @param k lower bound for digits in extension
     */
    private void recursion(Set<Integer> c, int s, int k, int n) {
        for (int i = k; isLessThanMax(i); i++) {
            if (!c.contains(i) && s >= i) {
                c.add(i);
                generate(c, s - i, n - 1, i + 1);
                c.remove(i);
            }
        }
    }
    
    /**
     * Adds s to combination.
     * @param c given combination to be extended
     * @param s digit sum for extension
     * @param k lower bound for digits in extension
     */
    private void addDigit(int k, int s, Set<Integer> c) {
        if (conditionBoundaries(k, s, c)) {
            c.add(s);
            observer.objectGenerated(this);
            c.remove(s);
        }
    }
    
    /**
     * Tests if two numbers are 0.
     * @param n first number
     * @param s second number
     * @return true if they are both 0, false otherwise
     */
    private boolean areZeroes(int n, int s) {
        return (n == 0 && s == 0);
    }

    /**
     * Compares s to k.
     * @param s first number
     * @param k second number
     * @return true if s >= k, false otherwise
     */
    private boolean isSGreaterThanK(int s, int k) {
        return (s >= k);
    }

    /**
     * Determines if a set c contains a number s.
     * @param c the set
     * @param s the number
     * @return true if c contains s, false otherwise
     */
    private boolean containsS(Set<Integer> c, int s) {
        return c.contains(s);
    }

    /**
     * Checks if a number is negative.
     * @param n the number
     * @return true if n is negative, false otherwise
     */
    private boolean isNNegative(int n) {
        return n < 0;
    }

    /**
     * Checks if a number is less than one.
     * @param k the number
     * @return true if k is less than 1, false otherwise
     */
    private boolean isLessThanOne(int k) {
        return k < 1;
    }

    /**
     * Checks if a number is less than the product of two other numbers.
     * @param s the first number
     * @param n the first number we multiply
     * @param k the second number we multiply
     * @return true if s is less than n * k, false otherwise
     */
    private boolean isSLessThanProduct(int s, int n, int k) {
        return s < n * k;
    }

    /**
     * Checks is a number is less than maxNumber.
     * @param a the number
     * @return true if a is less than maxNumber, false otherwise
     */
    private boolean isLessThanMax(int a) {
        return a <= maxNumber;
    }

    /**
     * Checks if a number is equal to 1.
     * @param a the number
     * @return true if a == 1, false otherwise
     */
    private boolean equalsOne(int a) {
        return a == 1;
    }

    /**
     * Checks if s is less than k, if s is less than maxNumber and if a set c contains s.
     * @param k first number
     * @param s second number
     * @param c the set
     * @return false if c does not contain s, true otherwise
     */
    private boolean conditionBoundaries(int k, int s, Set<Integer> c) {        
        return isSGreaterThanK(s, k) && isLessThanMax(s) && !containsS(c, s);
    }
    
    /**
     * Checks if s is negative, less than the product of n and k, and if k is less than 1.
     * @param s the first number
     * @param n the second number
     * @param k the third number
     * @return  true if at least one condition is true, false if all of them are false
     */
    private boolean conditionCreator(int s, int n, int k) {
        boolean x = isNNegative(n);
        boolean y = isSLessThanProduct(s, n, k);
        boolean z = isLessThanOne(k);
        return x || y || z;
    }
}